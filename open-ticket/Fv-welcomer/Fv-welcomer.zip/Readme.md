# Fv-welcomer
plugin to add in your all in one bot(openticket) to welcome a user

you can change the mebed message in index.ts for help contact me https://fv.dev.qreen.tech

> this only works with open ticket 