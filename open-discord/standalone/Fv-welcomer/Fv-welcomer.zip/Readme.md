# 🎉 Fv-Welcomer

**A simple welcome plugin for your all-in-one bot: [OpenDiscord](https://dj-dj.be)**
Make your users feel welcome right away when they join your discord.

---

## 🚀 What does it do?

This plugin:

- Automatically sends an embed welcome message when someone joins the discord.
- Works seamlessly with OpenDiscord.
- Is easy to customize to your style.

---

## ⚙️ Installation

1. Add `fv-welcomer` to your bot project in the "plugins" folder.
2. Customize the welcome message in `index.ts` to your liking.
3. Still have questions or errors? You can report them to [our site](fv.dev.qreen.tech)

---

## 🔜 
1. a cofig file


